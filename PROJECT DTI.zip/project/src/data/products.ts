export const products = [
  {
    id: '1',
    name: 'Organic Bananas (6 pcs)',
    image: 'https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&q=80',
    zeptoPrice: 45,
    blinkitPrice: 42,
    category: 'Fruits'
  },
  {
    id: '2',
    name: 'Fresh Milk (1L)',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&q=80',
    zeptoPrice: 68,
    blinkitPrice: 70,
    category: 'Dairy'
  },
  {
    id: '3',
    name: 'Whole Wheat Bread',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80',
    zeptoPrice: 35,
    blinkitPrice: 35,
    category: 'Bakery'
  },
  {
    id: '4',
    name: 'Farm Fresh Eggs (12 pcs)',
    image: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&q=80',
    zeptoPrice: 89,
    blinkitPrice: 85,
    category: 'Dairy'
  },
  {
    id: '5',
    name: 'Red Bell Peppers (500g)',
    image: 'https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?auto=format&fit=crop&q=80',
    zeptoPrice: 75,
    blinkitPrice: 78,
    category: 'Vegetables'
  },
  {
    id: '6',
    name: 'Instant Coffee (100g)',
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&q=80',
    zeptoPrice: 185,
    blinkitPrice: 180,
    category: 'Beverages'
  },
  {
    id: '7',
    name: 'Toilet Paper (6 rolls)',
    image: 'https://images.unsplash.com/photo-1583251633146-d0c6c036187d?auto=format&fit=crop&q=80',
    zeptoPrice: 165,
    blinkitPrice: 159,
    category: 'Household'
  },
  {
    id: '8',
    name: 'Toothpaste (150g)',
    image: 'https://images.unsplash.com/photo-1587778082149-bd5b1bf5d3fa?auto=format&fit=crop&q=80',
    zeptoPrice: 98,
    blinkitPrice: 95,
    category: 'Personal Care'
  },
  {
    id: '9',
    name: 'Dish Soap (500ml)',
    image: 'https://images.unsplash.com/photo-1622456491014-5e633ffb8a8d?auto=format&fit=crop&q=80',
    zeptoPrice: 89,
    blinkitPrice: 92,
    category: 'Household'
  },
  {
    id: '10',
    name: 'Rice (5kg)',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80',
    zeptoPrice: 325,
    blinkitPrice: 320,
    category: 'Groceries'
  },
  {
    id: '11',
    name: 'Cooking Oil (1L)',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&q=80',
    zeptoPrice: 175,
    blinkitPrice: 178,
    category: 'Groceries'
  },
  {
    id: '12',
    name: 'Onions (1kg)',
    image: 'https://images.unsplash.com/photo-1508747703725-719777637510?auto=format&fit=crop&q=80',
    zeptoPrice: 42,
    blinkitPrice: 40,
    category: 'Vegetables'
  },
  {
    id: '13',
    name: 'Tomatoes (500g)',
    image: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?auto=format&fit=crop&q=80',
    zeptoPrice: 35,
    blinkitPrice: 38,
    category: 'Vegetables'
  },
  {
    id: '14',
    name: 'Hand Sanitizer (250ml)',
    image: 'https://images.unsplash.com/photo-1584483766114-2cea6facdf57?auto=format&fit=crop&q=80',
    zeptoPrice: 85,
    blinkitPrice: 82,
    category: 'Personal Care'
  },
  {
    id: '15',
    name: 'Potato Chips (150g)',
    image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&q=80',
    zeptoPrice: 45,
    blinkitPrice: 45,
    category: 'Snacks'
  },
  {
    id: '16',
    name: 'Mixed Fruit Juice (1L)',
    image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&q=80',
    zeptoPrice: 125,
    blinkitPrice: 120,
    category: 'Beverages'
  },
  {
    id: '17',
    name: 'Laundry Detergent (2kg)',
    image: 'https://images.unsplash.com/photo-1610557892470-55d587a6c9d5?auto=format&fit=crop&q=80',
    zeptoPrice: 245,
    blinkitPrice: 249,
    category: 'Household'
  },
  {
    id: '18',
    name: 'Green Tea (25 bags)',
    image: 'https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e5?auto=format&fit=crop&q=80',
    zeptoPrice: 155,
    blinkitPrice: 152,
    category: 'Beverages'
  }
];