import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [selectedApp, setSelectedApp] = useState<'zepto' | 'blinkit' | null>(null);

  const handleRedirect = (app: 'zepto' | 'blinkit') => {
    // In a real app, these would be actual deep links to the respective apps
    const appUrls = {
      zepto: `zepto://product/${product.id}`,
      blinkit: `blinkit://product/${product.id}`
    };
    
    window.location.href = appUrls[app];
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105">
      <img 
        src={product.image} 
        alt={product.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-2 bg-purple-50 rounded">
            <span className="font-medium text-purple-700">Zepto</span>
            <span className="font-bold">₹{product.zeptoPrice}</span>
            <button
              onClick={() => handleRedirect('zepto')}
              className="flex items-center text-purple-600 hover:text-purple-800"
            >
              Buy <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          </div>
          <div className="flex items-center justify-between p-2 bg-green-50 rounded">
            <span className="font-medium text-green-700">Blinkit</span>
            <span className="font-bold">₹{product.blinkitPrice}</span>
            <button
              onClick={() => handleRedirect('blinkit')}
              className="flex items-center text-green-600 hover:text-green-800"
            >
              Buy <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          </div>
        </div>
        {product.blinkitPrice !== product.zeptoPrice && (
          <div className="mt-4 text-sm text-green-600 font-medium">
            Save ₹{Math.abs(product.blinkitPrice - product.zeptoPrice)} by choosing{' '}
            {product.blinkitPrice < product.zeptoPrice ? 'Blinkit' : 'Zepto'}
          </div>
        )}
      </div>
    </div>
  );
}