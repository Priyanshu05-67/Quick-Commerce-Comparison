import React, { useState } from 'react';
import { Search, ShoppingCart, TrendingUp, Clock, ArrowRight } from 'lucide-react';
import { ProductCard } from './components/ProductCard';
import { SearchBar } from './components/SearchBar';
import { products } from './data/products';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredProducts = products.filter(product => 
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div 
        className="bg-gradient-to-r from-purple-600 to-blue-500 text-white py-16"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&q=80')`,
          backgroundBlend: 'overlay',
          backgroundSize: 'cover'
        }}
      >
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Compare & Save
          </h1>
          <p className="text-xl mb-8">
            Find the best prices across quick commerce apps
          </p>
          <SearchBar 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <TrendingUp className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Real-time Prices</h3>
            <p className="text-gray-600">Compare prices across platforms instantly</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <ShoppingCart className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Direct Purchase</h3>
            <p className="text-gray-600">One-click redirect to your preferred app</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Clock className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Quick Delivery</h3>
            <p className="text-gray-600">Get your items delivered in minutes</p>
          </div>
        </div>

        {/* Products Section */}
        <h2 className="text-3xl font-bold mb-8">Popular Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;