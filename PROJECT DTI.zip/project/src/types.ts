export interface Product {
  id: string;
  name: string;
  image: string;
  zeptoPrice: number;
  blinkitPrice: number;
  category: string;
}